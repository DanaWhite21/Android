package com.example.camelcase2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Reg extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    EditText name;
    EditText pass;
    EditText email;
    Button signup;
    String UserName = "UserName";
    String UserPass = "UserPass";
    String UserEmail = "UserEmail";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg);
        sharedPreferences = getSharedPreferences("USerInfo", MODE_PRIVATE);
        name = (EditText) findViewById(R.id.name);
        pass = (EditText) findViewById(R.id.passedittext);
        email = (EditText) findViewById(R.id.email);
        signup = (Button) findViewById(R.id.signupbutton);

    }

    public void signup(View view) {
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.putString(UserName, name.getText().toString());
        edit.putString(UserPass, pass.getText().toString());
        edit.putString(UserEmail, email.getText().toString());
        edit.apply();

        Toast toast = Toast.makeText(getApplicationContext(),
                "Молодцы, а теперь авторизуйтесь", Toast.LENGTH_SHORT);
        toast.show();
        Intent intent = new Intent(Reg.this, AuthorizationActivity.class);
        startActivity(intent);

    }
}
